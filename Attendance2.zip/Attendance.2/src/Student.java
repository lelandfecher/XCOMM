
import java.io.Serializable;

public class Student implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String m_name;
	
	//Status = 0 for absent, 1 for present, and 2 for tardy
	private int m_status;
	
	public Student(String name) {
		m_name = name;
		m_status = 1;
	}
	

	
	public String getName()
	{
		return m_name;
	}
	
	public void setName(String name)
	{
		m_name = name;
	}
	
	public int getStatus()
	{
		return m_status;
	}
	
	public void setStatus(int status)
	{
		m_status = status;
	}
	
	public void setPresent()
	{
		m_status = 1;
	}
	
	public void setTardy()
	{
		m_status = 2;
	}
	
	public void setAbsent()
	{
		m_status = 0;
	}
}

